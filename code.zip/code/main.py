#!/usr/bin/env python3
"""
main.py — Terminal entry point for the claim-verification agent.

Usage:
    python main.py --strategy final --input ../dataset/claims.csv --output ../output.csv
    python main.py --strategy baseline --input ../dataset/sample_claims.csv --output /tmp/baseline.csv
    python main.py --strategy structured --input ../dataset/claims.csv --output /tmp/structured.csv

Required args:
    --input   path to a CSV with columns user_id, image_paths, user_claim, claim_object
    --output  path to write output.csv

Optional:
    --strategy  baseline | structured | final  (default: final)
    --model     override VLM_MODEL env var
    --limit N   process only the first N rows (for quick smoke tests)
    --no-cache  bypass the on-disk VLM response cache
    --verbose   DEBUG-level logging
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

# Make sure sibling modules import cleanly when run as `python code/main.py`
HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from agent import verify_claim  # noqa: E402
from data_loader import (  # noqa: E402
    find_claim_root_path,
    load_claims,
    load_evidence_requirements,
    load_user_history,
    write_csv,
)
from schemas import OUTPUT_COLUMNS  # noqa: E402
from utils import get_logger  # noqa: E402
from vlm_client import get_usage, reset_usage  # noqa: E402

LOGGER = get_logger("main")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="HackerRank Orchestrate multi-modal evidence review agent")
    p.add_argument("--input", required=True, help="Path to claims CSV (input)")
    p.add_argument("--output", required=True, help="Path to write output CSV")
    p.add_argument("--strategy", default="final", choices=["baseline", "structured", "final"])
    p.add_argument("--model", default=None, help="Override VLM_MODEL env var")
    p.add_argument("--limit", type=int, default=None, help="Process only the first N rows")
    p.add_argument("--no-cache", action="store_true", help="Bypass the on-disk VLM response cache")
    p.add_argument("--verbose", action="store_true", help="Enable DEBUG logging")
    p.add_argument("--dataset-root", default=None, help="Override dataset root (default: auto-detect)")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    if args.verbose:
        import logging
        logging.getLogger().setLevel(logging.DEBUG)

    repo_root = args.dataset_root or find_claim_root_path()
    dataset_root = os.path.join(repo_root, "dataset")
    if not os.path.isdir(dataset_root):
        # Maybe dataset_root was given directly
        dataset_root = repo_root
    LOGGER.info(f"repo_root={repo_root} dataset_root={dataset_root}")

    # Load supporting tables
    user_history = load_user_history(os.path.join(dataset_root, "user_history.csv"))
    evidence_reqs = load_evidence_requirements(os.path.join(dataset_root, "evidence_requirements.csv"))
    claims = load_claims(args.input)
    if args.limit:
        claims = claims[: args.limit]
    LOGGER.info(f"loaded {len(claims)} claims, {len(user_history)} users, {len(evidence_reqs)} requirements")

    if args.no_cache:
        # Wipe cache by re-creating a DiskCache at a fresh dir
        os.environ["VLM_CACHE_DIR"] = "/tmp/vlm_cache_fresh"

    reset_usage()
    out_rows = []
    t0 = time.time()
    for i, row in enumerate(claims, start=1):
        LOGGER.info(f"=== row {i}/{len(claims)} user_id={row.get('user_id')} object={row.get('claim_object')} ===")
        out_row = verify_claim(
            row=row,
            user_history_lookup=user_history,
            evidence_requirements=evidence_reqs,
            dataset_root=dataset_root,
            strategy=args.strategy,
            model=args.model,
        )
        out_rows.append(out_row)
    elapsed = time.time() - t0

    # Write output CSV
    write_csv(args.output, out_rows, list(OUTPUT_COLUMNS))
    usage = get_usage()
    LOGGER.info(f"wrote {len(out_rows)} rows to {args.output}")
    LOGGER.info(
        f"usage: calls={usage['calls']} cache_hits={usage['cache_hits']} "
        f"prompt_tokens={usage['prompt_tokens']} completion_tokens={usage['completion_tokens']} "
        f"images_sent={usage['images_sent']} elapsed={elapsed:.1f}s"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
