"""
schemas.py — Allowed values for the Multi-Modal Evidence Review task.

All allowed enum values are defined here exactly as listed in
problem_statement.md. The agent uses these to:
  - build prompts that tell the VLM what it may emit
  - validate / normalize the VLM's output
  - map free-text model answers to the closest allowed value
"""

from __future__ import annotations

from typing import Iterable, List, Tuple

# ---------------------------------------------------------------------------
# Allowed enum values (verbatim from problem_statement.md)
# ---------------------------------------------------------------------------

CLAIM_STATUS_VALUES: Tuple[str, ...] = (
    "supported",
    "contradicted",
    "not_enough_information",
)

ISSUE_TYPE_VALUES: Tuple[str, ...] = (
    "dent",
    "scratch",
    "crack",
    "glass_shatter",
    "broken_part",
    "missing_part",
    "torn_packaging",
    "crushed_packaging",
    "water_damage",
    "stain",
    "none",
    "unknown",
)

SEVERITY_VALUES: Tuple[str, ...] = (
    "none",
    "low",
    "medium",
    "high",
    "unknown",
)

CAR_PARTS: Tuple[str, ...] = (
    "front_bumper",
    "rear_bumper",
    "door",
    "hood",
    "windshield",
    "side_mirror",
    "headlight",
    "taillight",
    "fender",
    "quarter_panel",
    "body",
    "unknown",
)

LAPTOP_PARTS: Tuple[str, ...] = (
    "screen",
    "keyboard",
    "trackpad",
    "hinge",
    "lid",
    "corner",
    "port",
    "base",
    "body",
    "unknown",
)

PACKAGE_PARTS: Tuple[str, ...] = (
    "box",
    "package_corner",
    "package_side",
    "seal",
    "label",
    "contents",
    "item",
    "unknown",
)

RISK_FLAGS: Tuple[str, ...] = (
    "none",
    "blurry_image",
    "cropped_or_obstructed",
    "low_light_or_glare",
    "wrong_angle",
    "wrong_object",
    "wrong_object_part",
    "damage_not_visible",
    "claim_mismatch",
    "possible_manipulation",
    "non_original_image",
    "text_instruction_present",
    "user_history_risk",
    "manual_review_required",
)

OBJECT_PARTS_BY_OBJECT = {
    "car": CAR_PARTS,
    "laptop": LAPTOP_PARTS,
    "package": PACKAGE_PARTS,
}

CLAIM_OBJECTS: Tuple[str, ...] = ("car", "laptop", "package")

# Output columns in the EXACT order required by problem_statement.md
OUTPUT_COLUMNS: Tuple[str, ...] = (
    "user_id",
    "image_paths",
    "user_claim",
    "claim_object",
    "evidence_standard_met",
    "evidence_standard_met_reason",
    "risk_flags",
    "issue_type",
    "object_part",
    "claim_status",
    "claim_status_justification",
    "supporting_image_ids",
    "valid_image",
    "severity",
)


# ---------------------------------------------------------------------------
# Synonyms used by the normalizer to map free-text VLM answers to allowed values.
# Keys are lower-cased free-text snippets; values are the canonical allowed value.
# Keep this list short and conservative — only obvious synonyms.
# ---------------------------------------------------------------------------

ISSUE_TYPE_SYNONYMS = {
    # glass / cracks
    "shattered glass": "glass_shatter",
    "glass shatter": "glass_shatter",
    "glass crack": "glass_shatter",
    "shattered": "glass_shatter",
    "cracked glass": "glass_shatter",
    "cracked windshield": "glass_shatter",
    "windshield crack": "crack",
    "windshield shatter": "glass_shatter",
    "screen crack": "crack",
    "screen shattered": "glass_shatter",
    "screen shatter": "glass_shatter",
    # packaging
    "torn package": "torn_packaging",
    "torn packaging": "torn_packaging",
    "torn seal": "torn_packaging",
    "open package": "torn_packaging",
    "opened package": "torn_packaging",
    "crushed package": "crushed_packaging",
    "crushed box": "crushed_packaging",
    "crushed corner": "crushed_packaging",
    "dented box": "crushed_packaging",
    # water / stain
    "water stain": "stain",
    "liquid stain": "stain",
    "liquid damage": "water_damage",
    "wet": "water_damage",
    "oil stain": "stain",
    # missing
    "missing keys": "missing_part",
    "missing key": "missing_part",
    "missing keycap": "missing_part",
    "missing item": "missing_part",
    "missing contents": "missing_part",
    "missing part": "missing_part",
    # broken
    "broken hinge": "broken_part",
    "broken headlight": "broken_part",
    "broken taillight": "broken_part",
    "broken mirror": "broken_part",
    "broken part": "broken_part",
    "broken component": "broken_part",
    "broken key": "broken_part",
    "broken item": "broken_part",
    # dents / scratches
    "small dent": "dent",
    "hail dent": "dent",
    "hail dents": "dent",
    "deep scratch": "scratch",
    "paint scratch": "scratch",
    "scrape": "scratch",
}

CAR_PART_SYNONYMS = {
    "front bumper": "front_bumper",
    "rear bumper": "rear_bumper",
    "back bumper": "rear_bumper",
    "door panel": "door",
    "side door": "door",
    "left door": "door",
    "right door": "door",
    "front glass": "windshield",
    "windshield glass": "windshield",
    "front windshield": "windshield",
    "side mirror": "side_mirror",
    "wing mirror": "side_mirror",
    "left mirror": "side_mirror",
    "right mirror": "side_mirror",
    "left side mirror": "side_mirror",
    "right side mirror": "side_mirror",
    "front light": "headlight",
    "front headlight": "headlight",
    "back light": "taillight",
    "tail light": "taillight",
    "rear light": "taillight",
    "head lamp": "headlight",
    "headlamp": "headlight",
    "car body": "body",
    "body panel": "body",
    "quarter panel": "quarter_panel",
}

LAPTOP_PART_SYNONYMS = {
    "laptop screen": "screen",
    "display": "screen",
    "laptop keyboard": "keyboard",
    "key": "keyboard",
    "keys": "keyboard",
    "keycap": "keyboard",
    "trackpad area": "trackpad",
    "touchpad": "trackpad",
    "palm rest": "trackpad",
    "laptop hinge": "hinge",
    "laptop lid": "lid",
    "outer lid": "lid",
    "laptop corner": "corner",
    "laptop body": "body",
    "side edge": "body",
    "outer body": "body",
    "base": "base",
}

PACKAGE_PART_SYNONYMS = {
    "package corner": "package_corner",
    "box corner": "package_corner",
    "cardboard corner": "package_corner",
    "package side": "package_side",
    "box side": "package_side",
    "seal": "seal",
    "package seal": "seal",
    "tape": "seal",
    "shipping label": "label",
    "package label": "label",
    "label area": "label",
    "box": "box",
    "cardboard box": "box",
    "shipping box": "box",
    "delivery box": "box",
    "package contents": "contents",
    "inner contents": "contents",
    "inside": "contents",
    "inside item": "item",
    "inner item": "item",
    "product": "item",
    "item inside": "item",
}

PART_SYNONYMS_BY_OBJECT = {
    "car": CAR_PART_SYNONYMS,
    "laptop": LAPTOP_PART_SYNONYMS,
    "package": PACKAGE_PART_SYNONYMS,
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def allowed_parts_for(claim_object: str) -> Tuple[str, ...]:
    return OBJECT_PARTS_BY_OBJECT.get(claim_object, ("unknown",))


def normalize_issue_type(value: str) -> str:
    if not value:
        return "unknown"
    v = value.strip().lower()
    if v in ISSUE_TYPE_VALUES:
        return v
    for k, mapped in ISSUE_TYPE_SYNONYMS.items():
        if k in v:
            return mapped
    # Last-resort fuzzy: substring match on each allowed value
    for allowed in ISSUE_TYPE_VALUES:
        if allowed in v or v in allowed:
            return allowed
    return "unknown"


def normalize_part(value: str, claim_object: str) -> str:
    if not value:
        return "unknown"
    v = value.strip().lower()
    allowed = allowed_parts_for(claim_object)
    if v in allowed:
        return v
    syn = PART_SYNONYMS_BY_OBJECT.get(claim_object, {})
    for k, mapped in syn.items():
        if k in v:
            return mapped
    for a in allowed:
        if a in v or v in a:
            return a
    return "unknown"


def normalize_severity(value: str) -> str:
    if not value:
        return "unknown"
    v = value.strip().lower()
    if v in SEVERITY_VALUES:
        return v
    # Synonyms
    if "severe" in v or "major" in v or "heavy" in v or "extensive" in v:
        return "high"
    if "moderate" in v or "medium" in v or "minor-moderate" in v:
        return "medium"
    if "minor" in v or "slight" in v or "small" in v or "light" in v:
        return "low"
    if "none" in v or "no damage" in v or "no visible" in v:
        return "none"
    return "unknown"


def normalize_claim_status(value: str) -> str:
    if not value:
        return "not_enough_information"
    v = value.strip().lower()
    if v in CLAIM_STATUS_VALUES:
        return v
    if "support" in v or "approve" in v or "accept" in v:
        return "supported"
    if "contradict" in v or "reject" in v or "mismatch" in v:
        return "contradicted"
    return "not_enough_information"


def normalize_risk_flags(value) -> List[str]:
    """Parse a free-text or list-like value into a list of allowed risk flags."""
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        items = [str(x) for x in value]
    else:
        s = str(value).strip().lower()
        if not s or s == "none":
            return []
        # Accept semicolon, comma, pipe, or whitespace as separators
        for sep in (";", "|", ","):
            if sep in s:
                items = [x.strip() for x in s.split(sep)]
                break
        else:
            items = s.split()
    out: List[str] = []
    for it in items:
        if not it:
            continue
        it_low = it.lower()
        if it_low == "none":
            continue
        if it_low in RISK_FLAGS:
            out.append(it_low)
            continue
        # Fuzzy match
        for allowed in RISK_FLAGS:
            if allowed in it_low or it_low in allowed:
                out.append(allowed)
                break
        else:
            # Unknown flag — drop it (we only emit allowed values)
            pass
    # Deduplicate while preserving order
    seen = set()
    deduped: List[str] = []
    for f in out:
        if f not in seen:
            seen.add(f)
            deduped.append(f)
    return deduped


def join_risk_flags(flags: Iterable[str]) -> str:
    cleaned = list(flags)
    if not cleaned:
        return "none"
    # If 'none' coexists with real flags, drop 'none'
    cleaned = [f for f in cleaned if f != "none"]
    if not cleaned:
        return "none"
    # Deduplicate preserving order
    seen = set()
    out = []
    for f in cleaned:
        if f not in seen:
            seen.add(f)
            out.append(f)
    return ";".join(out)


def format_bool(value) -> str:
    """Coerce a bool-like value to the lowercase string 'true' / 'false'."""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str):
        s = value.strip().lower()
        if s in ("true", "yes", "1", "t"):
            return "true"
        if s in ("false", "no", "0", "f"):
            return "false"
    return "true" if value else "false"
