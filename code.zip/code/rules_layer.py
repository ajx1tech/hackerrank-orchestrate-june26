"""
rules_layer.py — Deterministic post-VLM rules.

After the VLM returns a JSON answer, this module:
  1. Parses the JSON (with fallbacks for malformed output).
  2. Normalizes every field to the allowed values in schemas.py.
  3. Enforces cross-field invariants (e.g. valid_image=false implies
     evidence_standard_met=false; claim_mismatch implies a risk flag).
  4. Adds user-history risk flags when the user_history table justifies them.
  5. Validates supporting_image_ids against the actual image_ids submitted.
  6. Sanity-checks severity against the visible issue type.
  7. Auto-detects claim_mismatch by parsing the user_claim for the claimed
     issue_type and comparing to the per-image observed issue_type.
  8. Auto-detects multi-image object disagreement (different cars across
     images) and flips claim_status to not_enough_information.

The rules layer is what makes the `final` strategy different from
`structured`. It is also the place where we defend against VLM mistakes
(prompt-injection leakage, out-of-vocabulary values, missing fields).
"""

from __future__ import annotations

import json
import re
from typing import Dict, List, Optional

from schemas import (
    CLAIM_STATUS_VALUES,
    ISSUE_TYPE_VALUES,
    RISK_FLAGS,
    SEVERITY_VALUES,
    allowed_parts_for,
    format_bool,
    join_risk_flags,
    normalize_claim_status,
    normalize_issue_type,
    normalize_part,
    normalize_risk_flags,
    normalize_severity,
)


# ---------------------------------------------------------------------------
# JSON parsing with fallbacks
# ---------------------------------------------------------------------------

def parse_model_json(content: str) -> Dict:
    """Parse a JSON object out of the VLM's free-form text response.

    Tries, in order:
      1. Strict json.loads on the stripped content
      2. Extract the first {...} block and json.loads
      3. Extract a ```json fenced block and json.loads
      4. Last-ditch regex: find each "key": "value" pair
    """
    if not content:
        return {}
    s = content.strip()

    # Strip markdown code fences if present
    if s.startswith("```"):
        s = re.sub(r"^```(?:json)?\s*", "", s)
        s = re.sub(r"\s*```\s*$", "", s)
        s = s.strip()

    # Try strict
    try:
        return json.loads(s)
    except Exception:
        pass

    # Try first {...} block
    m = re.search(r"\{[\s\S]*\}", s)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            # Try fixing common issues (trailing commas)
            fixed = re.sub(r",\s*([}\]])", r"\1", m.group(0))
            try:
                return json.loads(fixed)
            except Exception:
                pass

    # Last-ditch key:value regex
    out: Dict = {}
    for km in re.finditer(r'"([a-zA-Z_]+)"\s*:\s*("([^"]*)"|true|false|null|\[[^\]]*\]|\d+)', s):
        key = km.group(1)
        raw = km.group(2)
        if raw.startswith('"'):
            out[key] = raw[1:-1]
        elif raw.startswith("["):
            # best-effort list parse
            inner = raw[1:-1].strip()
            if inner:
                items = [x.strip().strip('"') for x in inner.split(",")]
                out[key] = [x for x in items if x]
            else:
                out[key] = []
        elif raw in ("true", "false"):
            out[key] = raw == "true"
        elif raw == "null":
            out[key] = None
        else:
            try:
                out[key] = int(raw)
            except Exception:
                out[key] = raw
    return out


# ---------------------------------------------------------------------------
# Field normalization
# ---------------------------------------------------------------------------

def _coerce_bool(value, default: bool = True) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        s = value.strip().lower()
        if s in ("true", "yes", "1", "t"):
            return True
        if s in ("false", "no", "0", "f"):
            return False
    return default


def _coerce_list(value) -> List[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(x) for x in value]
    s = str(value).strip()
    if not s or s.lower() == "none":
        return []
    # Could be semicolon or comma separated
    for sep in (";", ","):
        if sep in s:
            return [x.strip() for x in s.split(sep) if x.strip()]
    return [s]


def _normalize_supporting_image_ids(value, valid_image_ids: List[str]) -> List[str]:
    """Filter the model's claimed supporting image IDs down to ones actually submitted."""
    raw = _coerce_list(value)
    if not raw or (len(raw) == 1 and raw[0].lower() == "none"):
        return []
    out = []
    valid_set = set(valid_image_ids)
    for x in raw:
        x_clean = x.strip().strip('"').strip("'")
        if not x_clean:
            continue
        if x_clean in valid_set:
            out.append(x_clean)
        else:
            # try prefix match (e.g. "image_1" vs "img_1")
            for v in valid_image_ids:
                if v in x_clean or x_clean in v:
                    out.append(v)
                    break
    # Deduplicate preserving order
    seen = set()
    dedup = []
    for x in out:
        if x not in seen:
            seen.add(x)
            dedup.append(x)
    return dedup


# ---------------------------------------------------------------------------
# Severity sanity checks
# ---------------------------------------------------------------------------

# Rough severity ceiling per issue_type — used to clamp over-estimates.
# The VLM tends to over-estimate severity (says "high" for moderate damage),
# so these ceilings are conservative. The gold labels mostly use "medium"
# for supported claims.
SEVERITY_CEILING = {
    "scratch": "low",
    "stain": "medium",
    "dent": "medium",  # default to medium unless very strong cues
    "crack": "medium",  # default to medium; only high if clearly shattered
    "glass_shatter": "high",
    "broken_part": "high",
    "missing_part": "high",
    "torn_packaging": "medium",
    "crushed_packaging": "high",
    "water_damage": "medium",  # default to medium; high only if severe
    "none": "none",
    "unknown": "unknown",
}

SEVERITY_RANK = {"none": 0, "low": 1, "medium": 2, "high": 3, "unknown": -1}

# Phrases in the per_image notes that, if present, justify raising the
# severity to high even when the issue_type ceiling is medium.
# These must be STRONG cues — "severe" alone is too generous since the VLM
# uses it loosely.
HIGH_SEVERITY_CUES = (
    "exposed metal",
    "exposed internal",
    "internal structure",
    "engine visible",
    "missing body panel",
    "crumpled",
    "shattered",
    "deep crack",
    "deep dent",
    "major damage",
    "heavily damaged",
    "burnt",
    "structural damage",
)


def _clamp_severity(severity: str, issue_type: str, contradicted: bool, per_image: List[Dict]) -> str:
    """Apply sanity ceiling. If contradicted, severity should usually be lower.

    The VLM tends to over-estimate severity (says "high" for moderate damage),
    so we use strict ceilings without cue-based exceptions. The gold labels
    mostly use "medium" for supported claims.
    """
    if severity == "unknown" or issue_type == "unknown":
        return severity
    ceiling = SEVERITY_CEILING.get(issue_type, "unknown")
    if ceiling == "unknown":
        return severity

    # If severity exceeds the ceiling for this issue type, clamp down
    if SEVERITY_RANK.get(severity, -1) > SEVERITY_RANK.get(ceiling, -1):
        return ceiling
    # If the claim is contradicted, cap severity at medium (it's not the
    # user's claimed damage; we are assessing only what IS visible).
    if contradicted and SEVERITY_RANK.get(severity, -1) > SEVERITY_RANK.get("medium", -1):
        return "medium"
    return severity


# ---------------------------------------------------------------------------
# User-claim text parser — derive what the user CLAIMED for cross-checking
# ---------------------------------------------------------------------------

# Maps substrings in the customer's chat transcript to issue_type values.
CLAIM_TEXT_TO_ISSUE = {
    "dent": "dent",
    "dents": "dent",
    "deep dent": "dent",
    "small dent": "dent",
    "hail dent": "dent",
    "scratch": "scratch",
    "scratched": "scratch",
    "scrape": "scratch",
    "scraped": "scratch",
    "paint mark": "scratch",
    "mark on": "scratch",
    "crack": "crack",
    "cracked": "crack",
    "shatter": "glass_shatter",
    "shattered": "glass_shatter",
    "broken": "broken_part",
    "broke": "broken_part",
    "missing": "missing_part",
    "fall off": "missing_part",
    "fell off": "missing_part",
    "came off": "missing_part",
    "torn": "torn_packaging",
    "tear": "torn_packaging",
    "opened": "torn_packaging",
    "open package": "torn_packaging",
    "torn open": "torn_packaging",
    "crush": "crushed_packaging",
    "crushed": "crushed_packaging",
    "dented box": "crushed_packaging",
    "wet": "water_damage",
    "water damage": "water_damage",
    "liquid damage": "water_damage",
    "spill": "water_damage",
    "spilled": "water_damage",
    "stain": "stain",
    "oily": "stain",
    "oil mark": "stain",
}

# Maps substrings in the customer's chat transcript to object_part values
# (kept per claim_object).
CLAIM_TEXT_TO_PART_CAR = {
    "front bumper": "front_bumper",
    "rear bumper": "rear_bumper",
    "back bumper": "rear_bumper",
    "door": "door",
    "hood": "hood",
    "windshield": "windshield",
    "front glass": "windshield",
    "side mirror": "side_mirror",
    "wing mirror": "side_mirror",
    "left mirror": "side_mirror",
    "right mirror": "side_mirror",
    "headlight": "headlight",
    "head light": "headlight",
    "taillight": "taillight",
    "tail light": "taillight",
    "back light": "taillight",
    "rear light": "taillight",
    "fender": "fender",
    "quarter panel": "quarter_panel",
    "body": "body",
    "body panel": "body",
}

CLAIM_TEXT_TO_PART_LAPTOP = {
    "screen": "screen",
    "display": "screen",
    "keyboard": "keyboard",
    "key": "keyboard",
    "keycap": "keyboard",
    "trackpad": "trackpad",
    "touchpad": "trackpad",
    "palm rest": "trackpad",
    "hinge": "hinge",
    "lid": "lid",
    "corner": "corner",
    "port": "port",
    "base": "base",
    "body": "body",
    "outer body": "body",
    "side edge": "body",
}

CLAIM_TEXT_TO_PART_PACKAGE = {
    "corner": "package_corner",
    "side": "package_side",
    "seal": "seal",
    "tape": "seal",
    "label": "label",
    "shipping label": "label",
    "box": "box",
    "cardboard": "box",
    "contents": "contents",
    "inside": "contents",
    "item": "item",
    "product": "item",
    "inner item": "item",
    "inside item": "item",
}

CLAIM_TEXT_TO_PART_BY_OBJECT = {
    "car": CLAIM_TEXT_TO_PART_CAR,
    "laptop": CLAIM_TEXT_TO_PART_LAPTOP,
    "package": CLAIM_TEXT_TO_PART_PACKAGE,
}


def parse_claimed_issue(user_claim: str) -> Optional[str]:
    """Return the issue_type the user claims, based on the transcript text.

    Returns None if no clear issue type can be parsed.
    """
    if not user_claim:
        return None
    s = user_claim.lower()
    # Priority order: longer / more specific phrases first
    items = sorted(CLAIM_TEXT_TO_ISSUE.items(), key=lambda x: -len(x[0]))
    for needle, issue in items:
        if needle in s:
            return issue
    return None


def parse_claimed_part(user_claim: str, claim_object: str) -> Optional[str]:
    """Return the object_part the user claims, based on the transcript text."""
    if not user_claim:
        return None
    mapping = CLAIM_TEXT_TO_PART_BY_OBJECT.get(claim_object, {})
    s = user_claim.lower()
    items = sorted(mapping.items(), key=lambda x: -len(x[0]))
    for needle, part in items:
        if needle in s:
            return part
    return None


# ---------------------------------------------------------------------------
# Multi-image disagreement detector
# ---------------------------------------------------------------------------

def _detect_multi_image_disagreement(per_image: List[Dict]) -> bool:
    """Return True if per-image analyses suggest different objects are shown.

    Heuristic: if the model marked different `object_visible` values across
    images, OR if the same image_ids report wildly different severities
    AND issue_types for the same claimed part, treat as disagreement.
    """
    if len(per_image) < 2:
        return False
    obj_vis = set()
    issue_types = set()
    for p in per_image:
        ov = str(p.get("object_visible", "unclear")).lower()
        if ov and ov != "unclear":
            obj_vis.add(ov)
        it = p.get("issue_type", "unknown")
        if it and it != "unknown" and it != "none":
            issue_types.add(it)
    # If images show different object categories, that's a clear disagreement
    if len(obj_vis) > 1:
        return True
    return False


# ---------------------------------------------------------------------------
# User-history risk flagging
# ---------------------------------------------------------------------------

def history_risk_flags(user_history: Optional[Dict]) -> List[str]:
    """Derive risk flags from the user_history row, if any."""
    if not user_history:
        return []
    flags: List[str] = []
    history_flags_str = user_history.get("history_flags", "none") or "none"
    if history_flags_str.lower() != "none":
        for f in history_flags_str.split(";"):
            f = f.strip().lower()
            if f and f != "none" and f in RISK_FLAGS:
                flags.append(f)
    # Quantitative triggers
    try:
        rejected = int(user_history.get("rejected_claim", 0) or 0)
        last_90 = int(user_history.get("last_90_days_claim_count", 0) or 0)
        manual = int(user_history.get("manual_review_claim", 0) or 0)
    except (ValueError, TypeError):
        rejected = last_90 = manual = 0
    if rejected >= 2 and "user_history_risk" not in flags:
        flags.append("user_history_risk")
    if last_90 >= 4 and "user_history_risk" not in flags:
        flags.append("user_history_risk")
    if manual >= 2 and "manual_review_required" not in flags:
        flags.append("manual_review_required")
    return flags


# ---------------------------------------------------------------------------
# Cross-field invariants
# ---------------------------------------------------------------------------

def apply_invariants(decision: Dict, ctx: Dict) -> Dict:
    """Enforce cross-field invariants on the normalized decision."""

    # 1. valid_image=false => evidence_standard_met=false, claim_status=not_enough_information
    if not decision["valid_image"]:
        decision["evidence_standard_met"] = False
        if decision["claim_status"] == "supported":
            decision["claim_status"] = "not_enough_information"

    # 2. evidence_standard_met=false => claim_status != supported
    if not decision["evidence_standard_met"] and decision["claim_status"] == "supported":
        decision["claim_status"] = "not_enough_information"

    # 3. claim_status=not_enough_information => evidence_standard_met=false
    if decision["claim_status"] == "not_enough_information":
        decision["evidence_standard_met"] = False

    # 4. claim_mismatch in risk_flags => claim_status != supported (unless we already are)
    if "claim_mismatch" in decision["risk_flags"] and decision["claim_status"] == "supported":
        # Mismatch found but model said supported — flip to contradicted unless
        # we genuinely lack enough info (then keep NEI).
        if decision["evidence_standard_met"]:
            decision["claim_status"] = "contradicted"
        else:
            decision["claim_status"] = "not_enough_information"

    # 5. wrong_object_part in risk_flags and claim_status=supported — DO NOT auto-demote.
    #    The model often flags wrong_object_part when the claimed part isn't the
    #    primary focus of the image, but that doesn't mean the claim is wrong.
    #    The _apply_claim_text_rules function handles genuine mismatches via
    #    the issue-type compatibility matrix. We only demote on wrong_object
    #    (different object entirely) and only when evidence is insufficient.
    if "wrong_object" in decision["risk_flags"] and decision["claim_status"] == "supported":
        # Only demote to NEI if evidence is genuinely insufficient.
        # If evidence is sufficient but the object is wrong, that's a contradiction,
        # handled by _apply_claim_text_rules.
        if not decision["evidence_standard_met"]:
            decision["claim_status"] = "not_enough_information"

    # 6. text_instruction_present in risk_flags => ensure manual_review_required also set
    if "text_instruction_present" in decision["risk_flags"] and "manual_review_required" not in decision["risk_flags"]:
        decision["risk_flags"].append("manual_review_required")

    # 7. possible_manipulation or non_original_image => manual_review_required + valid_image=false
    serious = {"possible_manipulation", "non_original_image"}
    if serious & set(decision["risk_flags"]):
        if "manual_review_required" not in decision["risk_flags"]:
            decision["risk_flags"].append("manual_review_required")
        decision["valid_image"] = False

    # 8. supporting_image_ids must be empty when claim_status=not_enough_information
    if decision["claim_status"] == "not_enough_information":
        decision["supporting_image_ids"] = []
    # 9. supporting_image_ids must be non-empty when claim_status in (supported, contradicted)
    elif decision["claim_status"] in ("supported", "contradicted") and not decision["supporting_image_ids"]:
        # If model failed to pick supporting images, default to all images that
        # the model marked as visible-and-relevant in per_image
        per_img = decision.get("_per_image", [])
        candidates = [p["image_id"] for p in per_img if p.get("visible") and p.get("claimed_part_visible")]
        if candidates:
            decision["supporting_image_ids"] = candidates[:3]
        else:
            # Fall back to all submitted image IDs
            decision["supporting_image_ids"] = list(ctx["image_ids"])

    # 10. issue_type=none => severity should be 'none' or 'unknown'
    if decision["issue_type"] == "none" and decision["severity"] not in ("none", "unknown"):
        decision["severity"] = "none"

    # 11. severity sanity ceiling given issue_type
    decision["severity"] = _clamp_severity(
        decision["severity"],
        decision["issue_type"],
        decision["claim_status"] == "contradicted",
        decision.get("_per_image", []),
    )

    # 12. risk_flags ordering: deterministic
    decision["risk_flags"] = _sort_risk_flags(decision["risk_flags"])

    return decision


# ---------------------------------------------------------------------------
# Auto-claim-mismatch detection (final strategy only)
# ---------------------------------------------------------------------------

def _apply_claim_text_rules(decision: Dict, ctx: Dict) -> Dict:
    """Use the user_claim text to detect mismatches the VLM may have missed.

    Logic:
      1. Parse the user_claim to find the claimed issue_type.
      2. For each per_image entry, check whether the visible issue_type is
         "compatible" with the claimed issue_type (see ISSUE_COMPATIBILITY).
      3. If compatible on at least one image → supported, issue_type = claimed.
         This OVERRIDES the model's claim_status if it said NEI or contradicted.
      4. If incompatible (visible damage is fundamentally different from claim)
         → contradicted, issue_type = visible.
      5. If multi-image disagreement (different object_visible categories OR
         one damaged + one explicitly intact) → NEI.
      6. If model said NEI but per_image shows compatible damage on claimed
         part, flip to supported (model was too cautious).
    """
    user_claim = ctx.get("user_claim", "")
    claim_object = ctx.get("claim_object", "")
    claimed_issue = parse_claimed_issue(user_claim)
    per_image = decision.get("_per_image", [])

    if claimed_issue and per_image:
        compatible_visible_issues = set()
        incompatible_visible_issues = set()
        for p in per_image:
            vis = p.get("issue_type")
            if not vis or vis in ("unknown", "none", ""):
                continue
            if _issues_compatible(claimed_issue, vis):
                compatible_visible_issues.add(vis)
            else:
                incompatible_visible_issues.add(vis)

        if compatible_visible_issues:
            # The user's claimed issue IS visible (compatible). Treat as supported.
            decision["issue_type"] = claimed_issue
            if "claim_mismatch" in decision["risk_flags"]:
                decision["risk_flags"].remove("claim_mismatch")
            # Override NEI / contradicted → supported (model was too cautious)
            # BUT only if there's no multi-image disagreement signal (wrong_object
            # in risk_flags suggests the model saw different objects across images).
            if "wrong_object" not in decision["risk_flags"]:
                if decision["evidence_standard_met"]:
                    decision["claim_status"] = "supported"
                else:
                    decision["evidence_standard_met"] = True
                    decision["claim_status"] = "supported"
        elif incompatible_visible_issues:
            # Visible damage is fundamentally different from claimed.
            if "claim_mismatch" not in decision["risk_flags"]:
                decision["risk_flags"].append("claim_mismatch")
            # Only flip supported → contradicted. Do NOT flip NEI → contradicted,
            # because NEI usually means the model saw a multi-image disagreement
            # or other quality issue that overrides the simple mismatch logic.
            if decision["claim_status"] == "supported" and decision["evidence_standard_met"]:
                decision["claim_status"] = "contradicted"
                from collections import Counter
                counter = Counter(incompatible_visible_issues)
                decision["issue_type"] = counter.most_common(1)[0][0]

    # Multi-image disagreement: ONLY flip to NEI when we have strong evidence
    # that the images show genuinely DIFFERENT OBJECTS (different object_visible
    # categories, e.g. one "car" and one "other"). A close-up + wide shot of
    # the SAME object is normal evidence, NOT disagreement, even if one image
    # shows damage and the other doesn't.
    if _detect_multi_image_disagreement(per_image):
        if "wrong_object" not in decision["risk_flags"]:
            decision["risk_flags"].append("wrong_object")
        if "claim_mismatch" not in decision["risk_flags"]:
            decision["risk_flags"].append("claim_mismatch")
        if decision["claim_status"] in ("supported", "contradicted"):
            decision["claim_status"] = "not_enough_information"
            decision["evidence_standard_met"] = False
    elif "wrong_object" in decision["risk_flags"] and "claim_mismatch" in decision["risk_flags"] and len(per_image) >= 2:
        # Model itself flagged BOTH wrong_object AND claim_mismatch on a
        # multi-image claim — trust the model's judgment that the images
        # show different objects. Flip to NEI.
        if decision["claim_status"] in ("supported", "contradicted"):
            decision["claim_status"] = "not_enough_information"
            decision["evidence_standard_met"] = False

    # If ALL per_image entries say damage_on_claimed_part="no" but model said
    # supported, flip to contradicted (the claimed part is visible but undamaged).
    if per_image and decision["claim_status"] == "supported":
        all_no_damage = all(
            p.get("damage_on_claimed_part") == "no" for p in per_image
        )
        any_part_visible = any(
            p.get("claimed_part_visible") for p in per_image
        )
        if all_no_damage and any_part_visible:
            decision["claim_status"] = "contradicted"
            if "damage_not_visible" not in decision["risk_flags"]:
                decision["risk_flags"].append("damage_not_visible")
            if "claim_mismatch" not in decision["risk_flags"]:
                decision["risk_flags"].append("claim_mismatch")
            decision["issue_type"] = "none"

    # If wrong_object is set on a single-image claim, the image is showing
    # a totally different object than claimed — that's a contradiction, not NEI.
    if "wrong_object" in decision["risk_flags"] and len(per_image) <= 1:
        if decision["claim_status"] == "supported":
            decision["claim_status"] = "contradicted"
            if "claim_mismatch" not in decision["risk_flags"]:
                decision["risk_flags"].append("claim_mismatch")

    return decision


# ---------------------------------------------------------------------------
# Issue-type compatibility matrix
# ---------------------------------------------------------------------------

# When the user claims issue X and the image shows issue Y, we treat the
# pair as "compatible" (the user's claim is supported by visible evidence)
# if Y is in COMPATIBLE_VISIBLE_ISSUES[X]. Otherwise it's a mismatch.
#
# These mappings encode domain knowledge: e.g. a dent is often part of
# larger broken_part damage, so dent-claim + broken_part-visible is
# still "supported". But scratch-claim + broken_part-visible is a
# contradiction (scratch is cosmetic, broken_part is structural).
COMPATIBLE_VISIBLE_ISSUES = {
    "dent": {"dent", "broken_part", "crushed_packaging"},  # dents often co-occur with broken parts
    "scratch": {"scratch", "stain"},  # scratches are cosmetic; only cosmetic things are compatible
    "crack": {"crack", "glass_shatter", "broken_part"},  # cracks and shatters are related
    "glass_shatter": {"glass_shatter", "crack", "broken_part"},
    "broken_part": {"broken_part", "crack", "glass_shatter", "missing_part", "dent"},
    "missing_part": {"missing_part", "broken_part"},
    "torn_packaging": {"torn_packaging", "crushed_packaging"},
    "crushed_packaging": {"crushed_packaging", "torn_packaging", "dent"},
    "water_damage": {"water_damage", "stain"},
    "stain": {"stain", "water_damage"},
    "none": set(),  # claim of "no damage" never compatible with visible damage
    "unknown": set(),  # unknown claim — fall through
}


def _issues_compatible(claimed: str, visible: str) -> bool:
    """Is a visible issue_type compatible with the user's claimed issue_type?"""
    if not claimed or not visible:
        return False
    if claimed == visible:
        return True
    compatible_set = COMPATIBLE_VISIBLE_ISSUES.get(claimed, set())
    return visible in compatible_set





def _sort_risk_flags(flags: List[str]) -> List[str]:
    """Sort risk flags in a canonical order (matches RISK_FLAGS order)."""
    order = {f: i for i, f in enumerate(RISK_FLAGS)}
    return sorted(set(flags), key=lambda f: order.get(f, 999))


# ---------------------------------------------------------------------------
# Per-image analysis extraction (used by invariants)
# ---------------------------------------------------------------------------

def _extract_per_image(model_json: Dict, valid_image_ids: List[str]) -> List[Dict]:
    """Pull out the per_image array and validate image_ids against what was submitted."""
    raw = model_json.get("per_image", [])
    if not isinstance(raw, list):
        return []
    out = []
    valid_set = set(valid_image_ids)
    for item in raw:
        if not isinstance(item, dict):
            continue
        img_id = str(item.get("image_id", "")).strip()
        if not img_id or img_id not in valid_set:
            # Try to match by position if image_id missing
            continue
        # If issue_type is unknown/none but other_issue_type is set, prefer other
        issue_type = normalize_issue_type(item.get("issue_type", ""))
        object_part_raw = item.get("object_part", "")
        if issue_type in ("unknown", "none", ""):
            other_it = normalize_issue_type(item.get("other_issue_type", ""))
            if other_it and other_it not in ("unknown", "none", ""):
                issue_type = other_it
                object_part_raw = item.get("other_object_part", object_part_raw)
        # If contains_text_instruction=true, ensure text_instruction_present is in flags
        flags = normalize_risk_flags(item.get("image_quality_flags", []))
        if _coerce_bool(item.get("contains_text_instruction"), False):
            if "text_instruction_present" not in flags:
                flags.append("text_instruction_present")
        out.append({
            "image_id": img_id,
            "visible": _coerce_bool(item.get("visible"), True),
            "object_visible": str(item.get("object_visible", "unclear")),
            "object_identity_notes": str(item.get("object_identity_notes", ""))[:200],
            "claimed_part_visible": _coerce_bool(item.get("claimed_part_visible"), True),
            "damage_on_claimed_part": str(item.get("damage_on_claimed_part", "unclear")),
            "issue_type_on_claimed_part": normalize_issue_type(item.get("issue_type_on_claimed_part", "")),
            "any_other_visible_damage": str(item.get("any_other_visible_damage", "no")),
            "other_issue_type": normalize_issue_type(item.get("other_issue_type", "")),
            "other_object_part": normalize_part(item.get("other_object_part", ""), ""),
            "issue_type": issue_type,
            "object_part": normalize_part(object_part_raw, ""),
            "severity": normalize_severity(item.get("severity", "")),
            "contains_text_instruction": _coerce_bool(item.get("contains_text_instruction"), False),
            "text_instruction_summary": str(item.get("text_instruction_summary", ""))[:200],
            "image_quality_flags": flags,
            "notes": str(item.get("notes", ""))[:200],
        })
    return out


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def apply_rules(model_json: Dict, ctx: Dict, strategy: str) -> Dict:
    """Convert a raw model JSON dict into a normalized, rule-checked decision dict.

    Returns a dict with the EXACT keys needed by the output CSV (minus the
    input columns user_id/image_paths/user_claim/claim_object which the
    caller will splice back in).
    """
    valid_image_ids: List[str] = ctx["image_ids"]
    claim_object = ctx["claim_object"]
    user_history = ctx.get("user_history")

    # --- extract per-image block (for structured/final) ---
    per_image = _extract_per_image(model_json, valid_image_ids) if strategy != "baseline" else []

    # --- normalize scalar fields ---
    evidence_standard_met = _coerce_bool(model_json.get("evidence_standard_met"), True)
    valid_image = _coerce_bool(model_json.get("valid_image"), True)
    issue_type = normalize_issue_type(model_json.get("issue_type", ""))
    object_part = normalize_part(model_json.get("object_part", ""), claim_object)
    claim_status = normalize_claim_status(model_json.get("claim_status", ""))
    severity = normalize_severity(model_json.get("severity", ""))
    risk_flags = normalize_risk_flags(model_json.get("risk_flags", []))
    supporting_image_ids = _normalize_supporting_image_ids(
        model_json.get("supporting_image_ids", []), valid_image_ids
    )

    # --- if model said issue_type=none but image shows clear damage, prefer per_image aggregate ---
    if per_image and issue_type in ("none", "unknown", ""):
        non_none = [p["issue_type"] for p in per_image if p["issue_type"] not in ("none", "unknown", "")]
        if non_none:
            issue_type = non_none[0]

    # --- aggregate per-image quality flags into top-level risk_flags ---
    for p in per_image:
        for f in p.get("image_quality_flags", []):
            if f not in risk_flags and f != "none":
                risk_flags.append(f)

    # --- add user-history-derived flags (final strategy only) ---
    if strategy == "final":
        hist_flags = history_risk_flags(user_history)
        for f in hist_flags:
            if f not in risk_flags and f != "none":
                risk_flags.append(f)

    # --- assemble decision dict ---
    decision = {
        "evidence_standard_met": evidence_standard_met,
        "evidence_standard_met_reason": _short_reason(model_json.get("evidence_standard_met_reason", ""), ctx, strategy),
        "risk_flags": risk_flags,
        "issue_type": issue_type,
        "object_part": object_part,
        "claim_status": claim_status,
        "claim_status_justification": _short_justification(model_json.get("claim_status_justification", ""), ctx),
        "supporting_image_ids": supporting_image_ids,
        "valid_image": valid_image,
        "severity": severity,
        "_per_image": per_image,
    }

    # --- apply cross-field invariants ---
    decision = apply_invariants(decision, ctx)

    # --- apply claim-text-derived rules (final strategy only) ---
    if strategy == "final":
        decision = _apply_claim_text_rules(decision, ctx)
        # Re-run invariants because the claim-text rules may have changed claim_status
        decision = apply_invariants(decision, ctx)

    # --- final string formatting ---
    out = {
        "evidence_standard_met": format_bool(decision["evidence_standard_met"]),
        "evidence_standard_met_reason": decision["evidence_standard_met_reason"],
        "risk_flags": join_risk_flags(decision["risk_flags"]),
        "issue_type": decision["issue_type"],
        "object_part": decision["object_part"],
        "claim_status": decision["claim_status"],
        "claim_status_justification": decision["claim_status_justification"],
        "supporting_image_ids": ";".join(decision["supporting_image_ids"]) if decision["supporting_image_ids"] else "none",
        "valid_image": format_bool(decision["valid_image"]),
        "severity": decision["severity"],
    }
    return out


# ---------------------------------------------------------------------------
# Reason / justification polishers
# ---------------------------------------------------------------------------

def _short_reason(value: str, ctx: Dict, strategy: str) -> str:
    s = (value or "").strip()
    if not s:
        # Synthesize a minimal reason
        if strategy == "baseline":
            s = "Image set evaluated against the claim."
        else:
            s = "Image set evaluated against the claim and minimum evidence requirements."
    # Clamp to ~200 chars
    if len(s) > 240:
        s = s[:237] + "..."
    return s


def _short_justification(value: str, ctx: Dict) -> str:
    s = (value or "").strip()
    if not s:
        # Synthesize a minimal justification
        s = "Decision based on the submitted image evidence."
    if len(s) > 360:
        s = s[:357] + "..."
    return s
