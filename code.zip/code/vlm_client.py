"""
vlm_client.py — Unified VLM client for the agent.

This module wraps every vision-language model call behind a single
function `call_vlm(prompt, images, system, model, strategy)` so the rest
of the agent doesn't care which VLM is in use.

Backends:
  - glm-4.6v via Node bridge (default; no API key required in this env)
  - OpenAI-compatible (gpt-4o, etc.) if OPENAI_API_KEY is set and
    VLM_MODEL starts with "gpt-"
  - Anthropic (claude-3.5-sonnet, etc.) if ANTHROPIC_API_KEY is set and
    VLM_MODEL starts with "claude-"

All responses are cached to disk (key = sha256(model+system+prompt+image bytes))
so re-runs are deterministic and free.
"""

from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from utils import (
    DiskCache,
    cache_key,
    env_int,
    env_str,
    get_logger,
    retry_with_backoff,
)

LOGGER = get_logger("vlm")


class _RateLimitError(Exception):
    """Raised when the VLM backend returns a 429 Too Many Requests response."""


# ---------------------------------------------------------------------------
# Module-level configuration
# ---------------------------------------------------------------------------

DEFAULT_MODEL = env_str("VLM_MODEL", "glm-4.6v")
CACHE_DIR = env_str("VLM_CACHE_DIR", str(Path(__file__).parent / "cache"))
MAX_RETRIES = env_int("VLM_MAX_RETRIES", 3)

_CACHE = DiskCache(CACHE_DIR)


# Per-run usage counters. The evaluation harness reads these after the run.
USAGE = {
    "calls": 0,             # actual VLM API calls (excluding cache hits)
    "cache_hits": 0,        # cache hits (no API call)
    "prompt_tokens": 0,
    "completion_tokens": 0,
    "images_sent": 0,
    "retries": 0,
    "errors": 0,
}


def reset_usage() -> None:
    for k in USAGE:
        USAGE[k] = 0


def get_usage() -> Dict[str, int]:
    return dict(USAGE)


# ---------------------------------------------------------------------------
# Path to the Node bridge
# ---------------------------------------------------------------------------

NODE_HELPER = str(Path(__file__).parent / "node_vlm_helper.js")


# ---------------------------------------------------------------------------
# Backend dispatch
# ---------------------------------------------------------------------------

def call_vlm(
    prompt: str,
    images: List[str],
    system: str = "",
    model: Optional[str] = None,
    temperature: float = 0.0,
    max_tokens: int = 1024,
    thinking: str = "disabled",
    use_cache: bool = True,
) -> Dict:
    """Call the VLM with the given prompt + images. Returns:

        {
          "content": str,         # raw model text
          "prompt_tokens": int,
          "completion_tokens": int,
          "model": str,
          "from_cache": bool,
        }

    Caches on disk so identical calls are free on re-runs.
    """
    model = model or DEFAULT_MODEL
    key = cache_key(prompt, images, system, model)
    if use_cache:
        cached = _CACHE.get(key)
        if cached is not None:
            USAGE["cache_hits"] += 1
            return {**cached, "from_cache": True}

    # Dispatch by model name + available env vars
    backend = _pick_backend(model)
    if backend == "openai":
        result = _call_openai(prompt, images, system, model, temperature, max_tokens)
    elif backend == "anthropic":
        result = _call_anthropic(prompt, images, system, model, temperature, max_tokens)
    else:
        result = _call_glm_via_node(prompt, images, system, model, temperature, max_tokens, thinking)

    if use_cache:
        _CACHE.put(key, result)
    USAGE["calls"] += 1
    USAGE["prompt_tokens"] += result.get("prompt_tokens", 0)
    USAGE["completion_tokens"] += result.get("completion_tokens", 0)
    USAGE["images_sent"] += len(images)
    return {**result, "from_cache": False}


def _pick_backend(model: str) -> str:
    if model.startswith("gpt-") and os.environ.get("OPENAI_API_KEY"):
        return "openai"
    if model.startswith("claude-") and os.environ.get("ANTHROPIC_API_KEY"):
        return "anthropic"
    return "glm"


# ---------------------------------------------------------------------------
# Image preprocessing — convert AVIF/WEBP/etc to JPEG
# ---------------------------------------------------------------------------

# Cache for already-converted images so we don't reconvert on every call
_CONVERTED_CACHE: Dict[str, str] = {}


def _preprocess_image(image_path: str) -> str:
    """Ensure the image is in a format the VLM accepts (JPEG or PNG).

    Some images in the dataset have a .jpg extension but are actually AVIF
    or WEBP. The z-ai VLM rejects those with error code 1210
    ("图片输入格式/解析错误"). We detect the true format via Pillow and
    convert AVIF/WEBP to JPEG on the fly, caching the result.

    Returns the path to a VLM-compatible image (original or converted).
    """
    if not image_path or not os.path.exists(image_path):
        return image_path

    # Check cache first
    if image_path in _CONVERTED_CACHE:
        cached = _CONVERTED_CACHE[image_path]
        if os.path.exists(cached):
            return cached

    try:
        from PIL import Image
        im = Image.open(image_path)
        fmt = (im.format or "").upper()

        # JPEG and PNG are accepted directly
        if fmt in ("JPEG", "PNG"):
            return image_path

        # Convert AVIF, WEBP, GIF, BMP, TIFF, etc. to JPEG
        if fmt in ("AVIF", "WEBP", "GIF", "BMP", "TIFF", "TGA"):
            # Convert to RGB (JPEG doesn't support alpha)
            if im.mode in ("RGBA", "LA", "P"):
                im = im.convert("RGB")
            elif im.mode != "RGB":
                im = im.convert("RGB")

            # Save to a temp file next to the original
            converted_dir = os.path.join(os.path.dirname(image_path), "_converted")
            os.makedirs(converted_dir, exist_ok=True)
            converted_path = os.path.join(
                converted_dir,
                os.path.splitext(os.path.basename(image_path))[0] + ".jpg"
            )
            im.save(converted_path, "JPEG", quality=90)
            _CONVERTED_CACHE[image_path] = converted_path
            LOGGER.debug(f"converted {image_path} ({fmt}) -> {converted_path} (JPEG)")
            return converted_path

        # Unknown format — try to convert anyway
        if im.mode != "RGB":
            im = im.convert("RGB")
        converted_dir = os.path.join(os.path.dirname(image_path), "_converted")
        os.makedirs(converted_dir, exist_ok=True)
        converted_path = os.path.join(
            converted_dir,
            os.path.splitext(os.path.basename(image_path))[0] + ".jpg"
        )
        im.save(converted_path, "JPEG", quality=90)
        _CONVERTED_CACHE[image_path] = converted_path
        return converted_path

    except Exception as e:
        LOGGER.warning(f"could not preprocess image {image_path}: {e}")
        return image_path


# ---------------------------------------------------------------------------
# glm-4.6v via Node bridge
# ---------------------------------------------------------------------------

def _call_glm_via_node(
    prompt: str,
    images: List[str],
    system: str,
    model: str,
    temperature: float,
    max_tokens: int,
    thinking: str,
) -> Dict:
    # Preprocess images: convert AVIF/WEBP/etc to JPEG (VLM only accepts JPEG/PNG)
    converted_images = [_preprocess_image(p) for p in images]

    payload = {
        "prompt": prompt,
        "images": converted_images,
        "system": system,
        "model": model,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "thinking": thinking,
    }
    payload_json = json.dumps(payload)

    # Make sure Node can resolve z-ai-web-dev-sdk (it's typically installed
    # via bun or in a non-standard global path). We extend NODE_PATH rather
    # than overriding it.
    node_path = os.environ.get("NODE_PATH", "")
    extra_paths = [
        "/home/z/.bun/install/global/node_modules",
        os.path.expanduser("~/.npm-global/lib/node_modules"),
        str(Path(__file__).parent / "node_modules"),
    ]
    extra_paths = [p for p in extra_paths if Path(p).exists()]
    if extra_paths:
        node_path = ":".join([p for p in [*extra_paths, node_path] if p])

    env = os.environ.copy()
    env["NODE_PATH"] = node_path

    def _attempt() -> Dict:
        proc = subprocess.run(
            ["node", NODE_HELPER],
            input=payload_json,
            capture_output=True,
            text=True,
            timeout=180,
            env=env,
        )
        if proc.returncode != 0:
            # The helper writes a JSON error object to stderr
            err = proc.stderr.strip() if proc.stderr else f"exit {proc.returncode}"
            # Detect 429 rate-limit errors and use a longer backoff
            if "429" in err or "Too many requests" in err:
                raise _RateLimitError(err[:500])
            raise RuntimeError(f"node_vlm_helper failed: {err[:500]}")
        out = proc.stdout.strip()
        if not out:
            raise RuntimeError("node_vlm_helper returned empty stdout")
        try:
            return json.loads(out)
        except json.JSONDecodeError as e:
            raise RuntimeError(f"node_vlm_helper returned non-JSON: {out[:200]}") from e

    # Use a longer backoff for rate-limit errors specifically
    try:
        result = retry_with_backoff(
            _attempt,
            max_attempts=MAX_RETRIES,
            base_delay=5.0,        # 5s, 10s, 20s for rate limits
            backoff_factor=2.0,
            logger=LOGGER,
        )
    except _RateLimitError:
        # One final long wait then retry
        LOGGER.warning("rate-limited 3x, sleeping 30s before final retry")
        time.sleep(30)
        result = _attempt()
    if not result.get("ok"):
        USAGE["errors"] += 1
        raise RuntimeError(f"node_vlm_helper error: {result.get('error', 'unknown')}")
    return {
        "content": result.get("content", ""),
        "prompt_tokens": result.get("prompt_tokens", 0),
        "completion_tokens": result.get("completion_tokens", 0),
        "model": result.get("model", model),
    }


# ---------------------------------------------------------------------------
# OpenAI-compatible backend (optional)
# ---------------------------------------------------------------------------

def _call_openai(
    prompt: str,
    images: List[str],
    system: str,
    model: str,
    temperature: float,
    max_tokens: int,
) -> Dict:
    try:
        from openai import OpenAI  # type: ignore
    except ImportError as e:
        raise RuntimeError("openai package not installed; pip install openai") from e

    client = OpenAI()
    import base64

    def _img_path_to_data_url(p: str) -> str:
        ext = "image/png" if p.lower().endswith(".png") else "image/jpeg"
        with open(p, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("ascii")
        return f"data:{ext};base64,{b64}"

    content: List[Dict] = [{"type": "text", "text": prompt}]
    for ip in images:
        # Preprocess: convert AVIF/WEBP to JPEG if needed
        converted = _preprocess_image(ip)
        content.append({"type": "image_url", "image_url": {"url": _img_path_to_data_url(converted)}})

    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": content})

    def _attempt() -> Dict:
        resp = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        choice = resp.choices[0]
        return {
            "content": choice.message.content or "",
            "prompt_tokens": getattr(resp.usage, "prompt_tokens", 0),
            "completion_tokens": getattr(resp.usage, "completion_tokens", 0),
            "model": model,
        }

    return retry_with_backoff(_attempt, max_attempts=MAX_RETRIES, logger=LOGGER)


# ---------------------------------------------------------------------------
# Anthropic backend (optional)
# ---------------------------------------------------------------------------

def _call_anthropic(
    prompt: str,
    images: List[str],
    system: str,
    model: str,
    temperature: float,
    max_tokens: int,
) -> Dict:
    try:
        import anthropic  # type: ignore
    except ImportError as e:
        raise RuntimeError("anthropic package not installed; pip install anthropic") from e

    client = anthropic.Anthropic()
    import base64
    import httpx

    def _img_to_content_block(p: str) -> Dict:
        ext = "image/png" if p.lower().endswith(".png") else "image/jpeg"
        with open(p, "rb") as f:
            b64 = base64.b64encode(f.read()).decode("ascii")
        return {"type": "image", "source": {"type": "base64", "media_type": ext, "data": b64}}

    blocks: List[Dict] = [{"type": "text", "text": prompt}]
    for ip in images:
        # Preprocess: convert AVIF/WEBP to JPEG if needed
        converted = _preprocess_image(ip)
        blocks.append(_img_to_content_block(converted))

    def _attempt() -> Dict:
        resp = client.messages.create(
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            system=system or anthropic.NOT_GIVEN,
            messages=[{"role": "user", "content": blocks}],
        )
        # Anthropic returns a list of content blocks; we want the text
        text = ""
        for b in resp.content:
            if getattr(b, "type", "") == "text":
                text += b.text
        return {
            "content": text,
            "prompt_tokens": getattr(resp.usage, "input_tokens", 0),
            "completion_tokens": getattr(resp.usage, "output_tokens", 0),
            "model": model,
        }

    return retry_with_backoff(_attempt, max_attempts=MAX_RETRIES, logger=LOGGER)
