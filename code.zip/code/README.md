# HackerRank Orchestrate — Multi-Modal Evidence Review Agent

Submission for the 24-hour HackerRank Orchestrate (June 2026) hackathon.
The agent verifies damage claims for **cars**, **laptops**, and **packages**
using a vision-language model, the claim chat transcript, user claim
history, and the minimum evidence requirements table.

## Approach in one paragraph

For each claim we (1) parse the chat transcript to extract the claimed
`issue_type` + `object_part` + severity cue, (2) call a vision-language
model on every submitted image in a single multi-image prompt that
constrains the output to the problem-statement allowed values, (3) apply
a deterministic rules layer that post-processes the model output
(prompt-injection text detection, claim-mismatch detection, user-history
risk flagging, allowed-value enforcement, severity sanity checks), and
(4) emit one row in `output.csv` per input row.

## Repo layout (post-build)

```
code/
├── README.md                  # you are here
├── requirements.txt           # python deps
├── main.py                    # terminal entry point
├── agent.py                   # core orchestration
├── vlm_client.py              # subprocess wrapper around Node VLM helper
├── node_vlm_helper.js         # Node.js bridge to z-ai-web-dev-sdk
├── prompts.py                 # 3 strategy prompts
├── rules_layer.py             # post-VLM deterministic rules
├── schemas.py                 # allowed values & validation
├── data_loader.py             # CSV + image loading
├── utils.py                   # logging, caching, retry
├── cache/                     # VLM response cache (auto-created)
└── evaluation/
    ├── main.py                # evaluation entry point
    ├── metrics.py             # accuracy / precision / recall / F1
    ├── compare_strategies.py  # runs 3 strategies on sample_claims
    └── evaluation_report.md   # operational analysis (auto-generated)
```

## Quickstart

```bash
# from repo root
cd code

# install python deps
pip install -r requirements.txt

# make sure the z-ai-web-dev-sdk is available (already installed in this env)
# the agent shells out to `node node_vlm_helper.js` under the hood

# 1) Run evaluation on sample_claims.csv (compares 3 strategies)
python evaluation/main.py

# 2) Run the final strategy on claims.csv to produce output.csv
python main.py --strategy final --input ../dataset/claims.csv \
       --output ../output.csv

# 3) (optional) Run a specific strategy on sample_claims.csv for inspection
python main.py --strategy baseline --input ../dataset/sample_claims.csv \
       --output /tmp/baseline_preds.csv
```

## Environment variables

The agent reads secrets **only** from environment variables:

| Var | Default | Purpose |
|---|---|---|
| `VLM_MODEL` | `glm-4.6v` | Vision model name (passed to z-ai-web-dev-sdk) |
| `OPENAI_API_KEY` | — | Optional. If set and `VLM_MODEL` starts with `gpt-`, the agent switches to the OpenAI Python SDK. |
| `ANTHROPIC_API_KEY` | — | Optional. If set and `VLM_MODEL` starts with `claude-`, the agent switches to the Anthropic Python SDK. |
| `VLM_CACHE_DIR` | `./cache` | Where to cache VLM responses (key = sha256 of prompt+images). |
| `VLM_MAX_RETRIES` | `3` | Retry attempts on transient VLM failures. |
| `VLM_CONCURRENCY` | `4` | Max parallel VLM calls. |
| `AGENT_STRATEGY` | `final` | Default strategy when `--strategy` is not passed. |

If neither `OPENAI_API_KEY` nor `ANTHROPIC_API_KEY` is set, the agent
uses the local `glm-4.6v` via the Node bridge. This is the configuration
used to produce the submitted `output.csv`.

## Strategies

| Strategy | Prompt | Rules layer | Description |
|---|---|---|---|
| `baseline` | minimal | none | Single VLM call, free-form prompt asking for all fields. |
| `structured` | JSON-schema, allowed-values | none | Single VLM call, system prompt lists every allowed enum value. |
| `final` | JSON-schema, allowed-values | yes | Strategy `structured` + deterministic rules layer (injection detection, mismatch checks, history flags, severity sanity). |

The `final` strategy is what produced `../output.csv`.

## Determinism

VLMs are stochastic. We mitigate non-determinism via:

- `temperature=0` / `thinking=disabled` on every VLM call
- Response cache keyed on `sha256(prompt || image-bytes)` — re-runs are exact replays
- Allowed-value enforcement in `rules_layer.normalize_output()` — the
  CSV always contains schema-valid values even if the model emits
  something out of vocabulary

## Evaluation

`evaluation/main.py` runs all three strategies on `sample_claims.csv`
and writes:

- `evaluation/metrics.json` — per-strategy accuracy / precision / recall / F1 for `claim_status`, `issue_type`, `object_part`, `severity`
- `evaluation/per_row_predictions.csv` — every strategy's prediction next to the gold answer
- `evaluation/evaluation_report.md` — operational analysis (model calls, tokens, images, cost, latency, TPM/RPM, batching/caching/retry notes)

## Hard-requirement checklist

- [x] Reads `dataset/claims.csv`, `dataset/user_history.csv`, `dataset/evidence_requirements.csv`, local images
- [x] Produces `output.csv` with the exact 14-column schema in problem-statement order
- [x] Includes `evaluation/` folder with multi-strategy comparison
- [x] No hardcoded test labels or file-specific answers
- [x] Reads secrets from env vars only — no hardcoded API keys
- [x] README inside `code/`

## Files outside this folder

- `../output.csv` — final predictions, one row per row in `dataset/claims.csv`
- `~/hackerrank_orchestrate/log.txt` — chat transcript (developer ↔ AI tool conversation log)
