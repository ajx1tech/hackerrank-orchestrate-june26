#!/usr/bin/env node
/**
 * node_vlm_helper.js — Bridge between the Python agent and z-ai-web-dev-sdk.
 *
 * Why this exists:
 *   The Python agent wants to call glm-4.6v (the only VLM available in this
 *   dev environment). z-ai-web-dev-sdk is a Node.js SDK and exposes no
 *   OpenAI-compatible HTTP endpoint we can hit directly from Python.
 *   Rather than re-implement auth + upload in Python, we shell out to this
 *   tiny Node script for every VLM call.
 *
 * Protocol:
 *   stdin  : a single JSON object { images: [absPath,...], prompt: string,
 *             system?: string, model?: string, temperature?: number,
 *             max_tokens?: number, thinking?: 'enabled'|'disabled' }
 *   stdout : a single JSON object { ok: true, content: string,
 *             prompt_tokens: int, completion_tokens: int, model: string }
 *           OR { ok: false, error: string }
 *
 * The Python side parses the stdout JSON. No network ports, no daemons.
 */

const fs = require("fs");

async function main() {
  let raw;
  try {
    raw = fs.readFileSync(0, "utf-8"); // read from stdin
  } catch (e) {
    console.error(JSON.stringify({ ok: false, error: "failed to read stdin: " + e.message }));
    process.exit(2);
  }

  let req;
  try {
    req = JSON.parse(raw);
  } catch (e) {
    console.error(JSON.stringify({ ok: false, error: "invalid JSON on stdin: " + e.message }));
    process.exit(2);
  }

  const images = Array.isArray(req.images) ? req.images : [];
  const prompt = req.prompt || "";
  const system = req.system || "";
  const model = req.model || "glm-4.6v";
  const temperature = typeof req.temperature === "number" ? req.temperature : 0;
  const maxTokens = req.max_tokens || 1024;
  const thinking = req.thinking === "enabled" ? { type: "enabled" } : { type: "disabled" };

  // Resolve z-ai-web-dev-sdk wherever it lives. We try several locations:
  //   1. local ./node_modules (developer's normal install)
  //   2. ~/.bun/install/global/node_modules (this dev env)
  //   3. ~/.npm-global/lib/node_modules (npm global)
  //   4. NODE_PATH env var
  // ESM `import()` does NOT honor NODE_PATH directly, so we resolve an
  // absolute path ourselves before importing.
  let ZAI;
  const path = require("path");
  const os = require("os");
  const candidateBases = [
    path.join(__dirname, "node_modules"),
    path.join(os.homedir(), ".bun", "install", "global", "node_modules"),
    path.join(os.homedir(), ".npm-global", "lib", "node_modules"),
    ...(process.env.NODE_PATH || "").split(":").filter(Boolean),
  ];
  let resolved = null;
  for (const base of candidateBases) {
    const cand = path.join(base, "z-ai-web-dev-sdk");
    if (fs.existsSync(path.join(cand, "package.json"))) {
      resolved = cand;
      break;
    }
  }
  try {
    if (resolved) {
      // Import via absolute path to the package's main ESM entry
      const pkg = JSON.parse(fs.readFileSync(path.join(resolved, "package.json"), "utf-8"));
      const entry = pkg.main || "dist/index.js";
      ZAI = (await import(path.join(resolved, entry))).default;
    } else {
      ZAI = (await import("z-ai-web-dev-sdk")).default;
    }
  } catch (e) {
    console.error(JSON.stringify({ ok: false, error: "z-ai-web-dev-sdk not installed: " + e.message }));
    process.exit(3);
  }

  // Build the message content
  const content = [];
  if (system) {
    // system is handled separately below; this branch is intentionally empty
  }
  content.push({ type: "text", text: prompt });
  for (const imgPath of images) {
    try {
      const buf = fs.readFileSync(imgPath);
      const b64 = buf.toString("base64");
      const ext = imgPath.toLowerCase().endsWith(".png") ? "image/png" : "image/jpeg";
      content.push({
        type: "image_url",
        image_url: { url: `data:${ext};base64,${b64}` },
      });
    } catch (e) {
      // Skip unreadable image but note it in the prompt-side text
      content.push({ type: "text", text: `[image ${imgPath} could not be read: ${e.message}]` });
    }
  }

  const messages = [];
  if (system) messages.push({ role: "system", content: system });
  messages.push({ role: "user", content });

  let zai;
  try {
    zai = await ZAI.create();
  } catch (e) {
    console.error(JSON.stringify({ ok: false, error: "ZAI.create() failed: " + e.message }));
    process.exit(4);
  }

  try {
    const resp = await zai.chat.completions.createVision({
      model,
      messages,
      temperature,
      max_tokens: maxTokens,
      thinking,
    });
    const choice = resp.choices && resp.choices[0];
    const content_out = choice && choice.message ? choice.message.content : "";
    const usage = resp.usage || {};
    console.log(JSON.stringify({
      ok: true,
      content: content_out,
      prompt_tokens: usage.prompt_tokens || 0,
      completion_tokens: usage.completion_tokens || 0,
      model: resp.model || model,
      request_id: resp.id || resp.request_id || null,
    }));
  } catch (e) {
    console.error(JSON.stringify({ ok: false, error: "createVision failed: " + (e && e.message ? e.message : String(e)) }));
    process.exit(5);
  }
}

main().catch((e) => {
  console.error(JSON.stringify({ ok: false, error: "unhandled: " + (e && e.message ? e.message : String(e)) }));
  process.exit(99);
});
