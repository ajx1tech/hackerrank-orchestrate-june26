# evaluation/ — Multi-strategy evaluation harness

This folder contains the evaluation pipeline required by the problem statement.

## Files

| File | Purpose |
|---|---|
| `main.py` | Terminal entry point. Runs the configured strategies on `dataset/sample_claims.csv`, writes `metrics.json`, `per_row_predictions.csv`, and `evaluation_report.md`. |
| `metrics.py` | Accuracy / precision / recall / F1 / Jaccard / composite exact-match computations. |
| `metrics.json` | Auto-generated. Full per-strategy metrics. |
| `per_row_predictions.csv` | Auto-generated. Every strategy's prediction next to the gold answer. |
| `evaluation_report.md` | Auto-generated. Operational analysis (model calls, tokens, cost, runtime, TPM/RPM). |

## Usage

```bash
# from repo root
cd code

# run all three strategies on the full sample set
python evaluation/main.py

# quick 5-row smoke test
python evaluation/main.py --limit 5

# run a subset of strategies
python evaluation/main.py --strategies baseline,final
```

## Strategies

| Strategy | Prompt | Rules layer | Purpose |
|---|---|---|---|
| `baseline` | minimal | none | Lower bound. |
| `structured` | JSON-schema + allowed-values | none | Shows the gain from structured prompting alone. |
| `final` | JSON-schema + allowed-values + reasoning steps | yes | Adds the deterministic post-VLM rules layer. This is what produces `output.csv`. |

The `final` strategy is what's used to generate the submitted `output.csv`.
