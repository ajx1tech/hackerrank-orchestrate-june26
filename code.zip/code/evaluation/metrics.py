"""
metrics.py — Compute accuracy / precision / recall / F1 for the agent's
predictions against the gold labels in sample_claims.csv.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Dict, List, Optional, Set, Tuple


# ---------------------------------------------------------------------------
# Field-level metrics
# ---------------------------------------------------------------------------

def accuracy(preds: List[str], golds: List[str]) -> float:
    if not golds:
        return 0.0
    correct = sum(1 for p, g in zip(preds, golds) if p == g)
    return correct / len(golds)


def per_class_metrics(preds: List[str], golds: List[str], label: str) -> Dict[str, float]:
    """Precision / recall / F1 for a single label (one-vs-rest)."""
    tp = sum(1 for p, g in zip(preds, golds) if p == label and g == label)
    fp = sum(1 for p, g in zip(preds, golds) if p == label and g != label)
    fn = sum(1 for p, g in zip(preds, golds) if p != label and g == label)
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    return {"precision": precision, "recall": recall, "f1": f1, "tp": tp, "fp": fp, "fn": fn}


def macro_f1(preds: List[str], golds: List[str]) -> float:
    labels = sorted(set(golds) | set(preds))
    if not labels:
        return 0.0
    f1s = [per_class_metrics(preds, golds, l)["f1"] for l in labels]
    return sum(f1s) / len(f1s)


def weighted_f1(preds: List[str], golds: List[str]) -> float:
    labels = sorted(set(golds) | set(preds))
    if not labels:
        return 0.0
    total = len(golds)
    weighted = 0.0
    for l in labels:
        weight = sum(1 for g in golds if g == l) / total
        weighted += weight * per_class_metrics(preds, golds, l)["f1"]
    return weighted


# ---------------------------------------------------------------------------
# Risk-flag set metrics (treating the semicolon-separated list as a set)
# ---------------------------------------------------------------------------

def parse_risk_flags(value: str) -> Set[str]:
    if not value:
        return set()
    s = value.strip().lower()
    if s == "none":
        return set()
    return {x.strip() for x in s.split(";") if x.strip() and x.strip() != "none"}


def risk_flag_metrics(pred_flags: List[str], gold_flags: List[str]) -> Dict[str, float]:
    """Jaccard-style set metrics over the union of all risk flags seen."""
    all_flags: Set[str] = set()
    for v in pred_flags + gold_flags:
        all_flags |= parse_risk_flags(v)

    if not all_flags:
        return {"precision": 1.0, "recall": 1.0, "f1": 1.0, "jaccard": 1.0}

    tp = fp = fn = 0
    jaccard_sum = 0.0
    for p, g in zip(pred_flags, gold_flags):
        p_set = parse_risk_flags(p)
        g_set = parse_risk_flags(g)
        tp += len(p_set & g_set)
        fp += len(p_set - g_set)
        fn += len(g_set - p_set)
        union = p_set | g_set
        if union:
            jaccard_sum += len(p_set & g_set) / len(union)
        else:
            jaccard_sum += 1.0

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    return {
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "jaccard_per_row": jaccard_sum / len(pred_flags) if pred_flags else 0.0,
    }


# ---------------------------------------------------------------------------
# Boolean metrics (for evidence_standard_met, valid_image)
# ---------------------------------------------------------------------------

def bool_metrics(preds: List[str], golds: List[str]) -> Dict[str, float]:
    """For boolean fields stored as 'true'/'false' strings."""
    p_norm = [str(p).strip().lower() for p in preds]
    g_norm = [str(g).strip().lower() for g in golds]
    acc = accuracy(p_norm, g_norm)
    # true-class metrics
    tp = sum(1 for p, g in zip(p_norm, g_norm) if p == "true" and g == "true")
    fp = sum(1 for p, g in zip(p_norm, g_norm) if p == "true" and g == "false")
    fn = sum(1 for p, g in zip(p_norm, g_norm) if p == "false" and g == "true")
    tn = sum(1 for p, g in zip(p_norm, g_norm) if p == "false" and g == "false")
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
    return {
        "accuracy": acc,
        "precision_true": precision,
        "recall_true": recall,
        "f1_true": f1,
        "tp": tp, "fp": fp, "fn": fn, "tn": tn,
    }


# ---------------------------------------------------------------------------
# Full evaluation report
# ---------------------------------------------------------------------------

def evaluate(pred_rows: List[Dict], gold_rows: List[Dict]) -> Dict:
    """Compare a list of predicted rows to the gold rows.

    Both lists must have the same length and be aligned by index.
    Returns a dict of metric blocks.
    """
    assert len(pred_rows) == len(gold_rows), f"len mismatch: {len(pred_rows)} vs {len(gold_rows)}"

    def col(rows, name):
        return [str(r.get(name, "")).strip() for r in rows]

    out: Dict = {}

    # claim_status
    cs_pred = col(pred_rows, "claim_status")
    cs_gold = col(gold_rows, "claim_status")
    out["claim_status"] = {
        "accuracy": accuracy(cs_pred, cs_gold),
        "macro_f1": macro_f1(cs_pred, cs_gold),
        "weighted_f1": weighted_f1(cs_pred, cs_gold),
        "per_class": {
            label: per_class_metrics(cs_pred, cs_gold, label)
            for label in sorted(set(cs_pred) | set(cs_gold))
        },
        "confusion": _confusion_matrix(cs_pred, cs_gold),
    }

    # issue_type
    it_pred = col(pred_rows, "issue_type")
    it_gold = col(gold_rows, "issue_type")
    out["issue_type"] = {
        "accuracy": accuracy(it_pred, it_gold),
        "macro_f1": macro_f1(it_pred, it_gold),
        "weighted_f1": weighted_f1(it_pred, it_gold),
        "per_class": {
            label: per_class_metrics(it_pred, it_gold, label)
            for label in sorted(set(it_pred) | set(it_gold))
        },
    }

    # object_part
    op_pred = col(pred_rows, "object_part")
    op_gold = col(gold_rows, "object_part")
    out["object_part"] = {
        "accuracy": accuracy(op_pred, op_gold),
        "macro_f1": macro_f1(op_pred, op_gold),
        "weighted_f1": weighted_f1(op_pred, op_gold),
    }

    # severity
    sv_pred = col(pred_rows, "severity")
    sv_gold = col(gold_rows, "severity")
    out["severity"] = {
        "accuracy": accuracy(sv_pred, sv_gold),
        "macro_f1": macro_f1(sv_pred, sv_gold),
        "weighted_f1": weighted_f1(sv_pred, sv_gold),
    }

    # evidence_standard_met
    es_pred = col(pred_rows, "evidence_standard_met")
    es_gold = col(gold_rows, "evidence_standard_met")
    out["evidence_standard_met"] = bool_metrics(es_pred, es_gold)

    # valid_image
    vi_pred = col(pred_rows, "valid_image")
    vi_gold = col(gold_rows, "valid_image")
    out["valid_image"] = bool_metrics(vi_pred, vi_gold)

    # risk_flags (set-based)
    rf_pred = col(pred_rows, "risk_flags")
    rf_gold = col(gold_rows, "risk_flags")
    out["risk_flags"] = risk_flag_metrics(rf_pred, rf_gold)

    # Composite "exact match" — all major categorical fields agree
    major_fields = ("claim_status", "issue_type", "object_part", "severity")
    exact = 0
    for p, g in zip(pred_rows, gold_rows):
        if all(str(p.get(f, "")).strip() == str(g.get(f, "")).strip() for f in major_fields):
            exact += 1
    out["composite_exact_match"] = {
        "n": len(pred_rows),
        "exact": exact,
        "rate": exact / len(pred_rows) if pred_rows else 0.0,
    }

    return out


def _confusion_matrix(preds: List[str], golds: List[str]) -> Dict[str, Dict[str, int]]:
    labels = sorted(set(preds) | set(golds))
    matrix = {g: {p: 0 for p in labels} for g in labels}
    for p, g in zip(preds, golds):
        matrix[g][p] += 1
    return matrix


# ---------------------------------------------------------------------------
# Pretty-printer for terminal output
# ---------------------------------------------------------------------------

def format_metrics_report(name: str, metrics: Dict) -> str:
    lines = [f"=== {name} ==="]
    cs = metrics.get("claim_status", {})
    lines.append(f"  claim_status:    acc={cs.get('accuracy', 0):.3f}  macro_f1={cs.get('macro_f1', 0):.3f}  weighted_f1={cs.get('weighted_f1', 0):.3f}")
    it = metrics.get("issue_type", {})
    lines.append(f"  issue_type:      acc={it.get('accuracy', 0):.3f}  macro_f1={it.get('macro_f1', 0):.3f}  weighted_f1={it.get('weighted_f1', 0):.3f}")
    op = metrics.get("object_part", {})
    lines.append(f"  object_part:     acc={op.get('accuracy', 0):.3f}  macro_f1={op.get('macro_f1', 0):.3f}  weighted_f1={op.get('weighted_f1', 0):.3f}")
    sv = metrics.get("severity", {})
    lines.append(f"  severity:        acc={sv.get('accuracy', 0):.3f}  macro_f1={sv.get('macro_f1', 0):.3f}  weighted_f1={sv.get('weighted_f1', 0):.3f}")
    es = metrics.get("evidence_standard_met", {})
    lines.append(f"  evid_standard:   acc={es.get('accuracy', 0):.3f}  f1_true={es.get('f1_true', 0):.3f}")
    vi = metrics.get("valid_image", {})
    lines.append(f"  valid_image:     acc={vi.get('accuracy', 0):.3f}  f1_true={vi.get('f1_true', 0):.3f}")
    rf = metrics.get("risk_flags", {})
    lines.append(f"  risk_flags:      p={rf.get('precision', 0):.3f}  r={rf.get('recall', 0):.3f}  f1={rf.get('f1', 0):.3f}  jaccard={rf.get('jaccard_per_row', 0):.3f}")
    ce = metrics.get("composite_exact_match", {})
    lines.append(f"  composite_exact: {ce.get('exact', 0)}/{ce.get('n', 0)} = {ce.get('rate', 0):.3f}")
    return "\n".join(lines)
