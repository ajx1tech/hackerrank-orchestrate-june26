"""
utils.py — Small shared utilities: logging, hashing, retry.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Optional, TypeVar

T = TypeVar("T")


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

_LOGGER: Optional[logging.Logger] = None


def get_logger(name: str = "agent") -> logging.Logger:
    global _LOGGER
    if _LOGGER is not None:
        return _LOGGER
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s %(name)s: %(message)s"))
    logger.addHandler(handler)
    _LOGGER = logger
    return logger


# ---------------------------------------------------------------------------
# Hashing / cache key
# ---------------------------------------------------------------------------

def sha256_of_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def cache_key(prompt: str, image_paths: Iterable[str], system: str = "", model: str = "") -> str:
    """Stable cache key for a VLM call.

    Includes the model name so changing the model invalidates the cache.
    Includes image file *contents* (hashed) so a replaced image invalidates.
    """
    h = hashlib.sha256()
    h.update(model.encode("utf-8"))
    h.update(b"\x00")
    h.update(system.encode("utf-8"))
    h.update(b"\x00")
    h.update(prompt.encode("utf-8"))
    for p in image_paths:
        try:
            with open(p, "rb") as f:
                img_bytes = f.read()
            h.update(b"\x01")
            h.update(p.encode("utf-8"))
            h.update(b"\x00")
            h.update(img_bytes)
        except Exception:
            h.update(b"\x02")
            h.update(p.encode("utf-8"))
    return h.hexdigest()


# ---------------------------------------------------------------------------
# Disk cache for VLM responses
# ---------------------------------------------------------------------------

class DiskCache:
    """Tiny on-disk JSON cache. Keys are hex strings."""

    def __init__(self, dirpath: str | Path):
        self.dir = Path(dirpath)
        self.dir.mkdir(parents=True, exist_ok=True)

    def get(self, key: str) -> Optional[Any]:
        p = self.dir / f"{key}.json"
        if not p.exists():
            return None
        try:
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    def put(self, key: str, value: Any) -> None:
        p = self.dir / f"{key}.json"
        try:
            with open(p, "w", encoding="utf-8") as f:
                json.dump(value, f)
        except Exception:
            pass  # cache failures must not crash the run


# ---------------------------------------------------------------------------
# Retry with exponential backoff
# ---------------------------------------------------------------------------

def retry_with_backoff(
    fn: Callable[[], T],
    max_attempts: int = 3,
    base_delay: float = 1.5,
    backoff_factor: float = 2.0,
    sleep_on_error: bool = True,
    logger: Optional[logging.Logger] = None,
) -> T:
    last_err: Optional[Exception] = None
    for attempt in range(1, max_attempts + 1):
        try:
            return fn()
        except Exception as e:
            last_err = e
            if logger:
                logger.warning(f"attempt {attempt}/{max_attempts} failed: {e}")
            if attempt >= max_attempts:
                break
            if sleep_on_error:
                delay = base_delay * (backoff_factor ** (attempt - 1))
                time.sleep(delay)
    assert last_err is not None
    raise last_err


# ---------------------------------------------------------------------------
# Env var helpers
# ---------------------------------------------------------------------------

def env_str(name: str, default: str) -> str:
    v = os.environ.get(name)
    return v if v is not None else default


def env_int(name: str, default: int) -> int:
    v = os.environ.get(name)
    if v is None:
        return default
    try:
        return int(v)
    except ValueError:
        return default


def env_float(name: str, default: float) -> float:
    v = os.environ.get(name)
    if v is None:
        return default
    try:
        return float(v)
    except ValueError:
        return default
