"""
data_loader.py — Load the dataset CSVs and resolve image paths.

This module knows nothing about VLMs. It just turns CSV rows into
Python dicts and resolves relative image paths to absolute file paths
so the rest of the agent can read the images off disk.
"""

from __future__ import annotations

import csv
import os
from pathlib import Path
from typing import Dict, List, Optional


# ---------------------------------------------------------------------------
# CSV readers
# ---------------------------------------------------------------------------

def read_csv(path: str | Path) -> List[Dict[str, str]]:
    """Read a CSV file into a list of dicts, preserving column order."""
    with open(path, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        rows = [dict(r) for r in reader]
    return rows


def write_csv(path: str | Path, rows: List[Dict[str, str]], columns: List[str]) -> None:
    """Write rows to a CSV with the given column order."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=columns, quoting=csv.QUOTE_ALL)
        writer.writeheader()
        for r in rows:
            row = {c: r.get(c, "") for c in columns}
            writer.writerow(row)


# ---------------------------------------------------------------------------
# Image path handling
# ---------------------------------------------------------------------------

def split_image_paths(image_paths_field: str) -> List[str]:
    """Split a semicolon-separated image_paths field into individual paths."""
    if not image_paths_field:
        return []
    return [p.strip() for p in image_paths_field.split(";") if p.strip()]


def image_id_from_path(path: str) -> str:
    """img_id is the filename without extension, e.g. 'img_1'."""
    return Path(path).stem


def resolve_image_path(rel_path: str, dataset_root: str | Path) -> str:
    """Resolve a repo-relative image path to an absolute path on disk.

    The CSV stores paths like 'images/test/case_001/img_1.jpg' — these are
    relative to the dataset/ folder. We resolve them against dataset_root.
    """
    p = Path(rel_path)
    if p.is_absolute() and p.exists():
        return str(p)
    candidate = Path(dataset_root) / rel_path
    if candidate.exists():
        return str(candidate)
    # Some path style fallbacks
    candidate2 = Path(dataset_root) / "dataset" / rel_path
    if candidate2.exists():
        return str(candidate2)
    return str(candidate)  # return best-guess even if missing


# ---------------------------------------------------------------------------
# Convenience loaders
# ---------------------------------------------------------------------------

def load_user_history(path: str | Path) -> Dict[str, Dict[str, str]]:
    rows = read_csv(path)
    return {r["user_id"]: r for r in rows}


def load_evidence_requirements(path: str | Path) -> List[Dict[str, str]]:
    return read_csv(path)


def load_claims(path: str | Path) -> List[Dict[str, str]]:
    return read_csv(path)


def load_sample_claims_with_labels(path: str | Path) -> List[Dict[str, str]]:
    """sample_claims.csv has input + expected output columns; return as-is."""
    return read_csv(path)


# ---------------------------------------------------------------------------
# Claim-text parsing helpers (used by the rules layer)
# ---------------------------------------------------------------------------

CLAIM_DELIMS = ["|", "\n"]


def split_claim_turns(user_claim: str) -> List[str]:
    """Split a claim transcript into individual turns.

    Transcripts look like:
        Customer: ... | Agent: ... | Customer: ...
    We split on '|' or newlines, then strip whitespace.
    """
    if not user_claim:
        return []
    s = user_claim
    for d in CLAIM_DELIMS:
        if d in s:
            s = s.replace(d, "\n")
    turns = [t.strip() for t in s.split("\n") if t.strip()]
    return turns


def extract_customer_statements(user_claim: str) -> List[str]:
    """Return only the customer-side statements from the transcript."""
    turns = split_claim_turns(user_claim)
    out = []
    for t in turns:
        low = t.lower()
        if low.startswith("customer:") or low.startswith("cliente:") or low.startswith("c:"):
            out.append(t.split(":", 1)[1].strip() if ":" in t else t)
        elif not low.startswith(("agent:", "support:", "soporte:", "a:", "s:")):
            # Statement with no clear speaker — assume customer
            out.append(t)
    return out


def find_claim_root_path() -> str:
    """Walk up from this file to find the repo root (the folder containing AGENTS.md)."""
    p = Path(__file__).resolve()
    for parent in [p.parent, *p.parents]:
        if (parent / "AGENTS.md").exists():
            return str(parent)
        if (parent.parent / "AGENTS.md").exists():
            return str(parent.parent)
    # Fallback — assume we're inside code/ two levels under repo root
    return str(p.parent.parent)
