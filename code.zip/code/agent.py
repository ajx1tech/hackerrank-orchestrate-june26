"""
agent.py — Core claim-verification orchestrator.

For each claim row, this module:
  1. Builds the strategy-specific (system, user) prompt.
  2. Calls the VLM with the prompt + the submitted images.
  3. Parses the model's JSON answer.
  4. Applies the deterministic rules layer.
  5. Returns a row ready to be written to output.csv.
"""

from __future__ import annotations

import time
from typing import Dict, List, Optional

from data_loader import (
    image_id_from_path,
    resolve_image_path,
    split_image_paths,
)
from prompts import build_prompt
from rules_layer import apply_rules, parse_model_json
from schemas import OUTPUT_COLUMNS
from utils import get_logger
from vlm_client import call_vlm

LOGGER = get_logger("agent")


# Evidence-requirement filter: which rows apply to a given claim?
def _relevant_evidence_requirements(
    all_reqs: List[Dict], claim_object: str, claimed_issue_type_hint: Optional[str] = None
) -> List[Dict]:
    """Pick the evidence requirements that apply to this claim.

    Rules:
      - requirement_id REQ_GENERAL_* and REQ_REVIEW_TRUST apply to every claim
      - requirement_id REQ_<OBJECT>_* applies when claim_object matches
      - applies_to text is included as-is for the model to read
    """
    out = []
    for r in all_reqs:
        ro = (r.get("claim_object") or "all").strip().lower()
        if ro == "all" or ro == claim_object:
            out.append(r)
    # Keep at most ~10 rows to bound prompt size
    return out[:10]


def build_claim_context(
    row: Dict[str, str],
    user_history_lookup: Dict[str, Dict],
    evidence_requirements: List[Dict],
    dataset_root: str,
) -> Dict:
    """Turn a CSV row into a fully-resolved claim context dict."""
    image_paths_field = row.get("image_paths", "")
    image_paths_rel = split_image_paths(image_paths_field)
    image_paths_abs = [resolve_image_path(p, dataset_root) for p in image_paths_rel]
    image_ids = [image_id_from_path(p) for p in image_paths_rel]
    user_id = row.get("user_id", "")
    claim_object = row.get("claim_object", "").strip().lower()
    user_history = user_history_lookup.get(user_id)
    relevant_reqs = _relevant_evidence_requirements(evidence_requirements, claim_object)
    return {
        "user_id": user_id,
        "image_paths_field": image_paths_field,
        "image_paths_rel": image_paths_rel,
        "image_paths_abs": image_paths_abs,
        "image_ids": image_ids,
        "user_claim": row.get("user_claim", ""),
        "claim_object": claim_object,
        "user_history": user_history,
        "evidence_requirements": relevant_reqs,
    }


def verify_claim(
    row: Dict[str, str],
    user_history_lookup: Dict[str, Dict],
    evidence_requirements: List[Dict],
    dataset_root: str,
    strategy: str = "final",
    model: Optional[str] = None,
    max_tokens: int = 1500,
) -> Dict[str, str]:
    """Run the full verification pipeline on a single claim row.

    Returns a dict with EVERY column in OUTPUT_COLUMNS, ready for csv.DictWriter.
    """
    t0 = time.time()
    ctx = build_claim_context(row, user_history_lookup, evidence_requirements, dataset_root)

    # Build prompt
    system, user = build_prompt(strategy, ctx)

    # Skip images that don't exist on disk (so the VLM doesn't error out)
    existing_images = [p for p in ctx["image_paths_abs"] if p and _file_exists(p)]
    if not existing_images:
        # No readable images — degenerate case
        LOGGER.warning(f"[{ctx['user_id']}] no readable images for paths={ctx['image_paths_field']}")
        decision = _no_image_fallback(ctx)
    else:
        # Call VLM
        try:
            resp = call_vlm(
                prompt=user,
                images=existing_images,
                system=system,
                model=model,
                temperature=0.0,
                max_tokens=max_tokens,
                thinking="disabled",
                use_cache=True,
            )
            content = resp.get("content", "")
        except Exception as e:
            LOGGER.error(f"[{ctx['user_id']}] VLM call failed: {e}")
            content = ""

        model_json = parse_model_json(content)
        if not model_json:
            LOGGER.warning(f"[{ctx['user_id']}] could not parse VLM JSON; using fallback. content[:200]={content[:200]!r}")
            decision = _unparseable_fallback(ctx, content)
        else:
            try:
                decision = apply_rules(model_json, ctx, strategy)
            except Exception as e:
                LOGGER.error(f"[{ctx['user_id']}] rules layer crashed: {e}; using fallback")
                decision = _unparseable_fallback(ctx, content)

    # Splice input columns back in
    out_row = {
        "user_id": ctx["user_id"],
        "image_paths": ctx["image_paths_field"],
        "user_claim": ctx["user_claim"],
        "claim_object": ctx["claim_object"],
    }
    out_row.update(decision)

    # Ensure every output column is present and is a string
    for col in OUTPUT_COLUMNS:
        if col not in out_row:
            out_row[col] = ""
        out_row[col] = str(out_row[col])

    elapsed = time.time() - t0
    LOGGER.info(
        f"[{ctx['user_id']}] strategy={strategy} status={out_row['claim_status']} "
        f"issue={out_row['issue_type']} part={out_row['object_part']} "
        f"severity={out_row['severity']} risk={out_row['risk_flags']} "
        f"elapsed={elapsed:.2f}s"
    )
    # Small delay between calls to stay under the RPM limit (~60 RPM for glm-4.6v)
    time.sleep(0.3)
    return out_row


# ---------------------------------------------------------------------------
# Fallbacks for degenerate cases
# ---------------------------------------------------------------------------

def _file_exists(p: str) -> bool:
    try:
        import os
        return os.path.exists(p) and os.path.getsize(p) > 0
    except Exception:
        return False


def _no_image_fallback(ctx: Dict) -> Dict[str, str]:
    """Used when none of the submitted image paths can be read from disk."""
    risk = ["cropped_or_obstructed", "damage_not_visible"]
    if ctx.get("user_history"):
        from rules_layer import history_risk_flags
        risk.extend(history_risk_flags(ctx["user_history"]))
    return {
        "evidence_standard_met": "false",
        "evidence_standard_met_reason": "No readable images were submitted for this claim.",
        "risk_flags": ";".join(sorted(set(risk))) if risk else "none",
        "issue_type": "unknown",
        "object_part": "unknown",
        "claim_status": "not_enough_information",
        "claim_status_justification": "The submitted image set could not be inspected.",
        "supporting_image_ids": "none",
        "valid_image": "false",
        "severity": "unknown",
    }


def _unparseable_fallback(ctx: Dict, raw_content: str) -> Dict[str, str]:
    """Used when the VLM returned content we couldn't parse as JSON.

    The agent must still emit a valid row.
    """
    risk = ["damage_not_visible"]
    if ctx.get("user_history"):
        from rules_layer import history_risk_flags
        risk.extend(history_risk_flags(ctx["user_history"]))
    return {
        "evidence_standard_met": "false",
        "evidence_standard_met_reason": "The model output could not be parsed into the required schema.",
        "risk_flags": ";".join(sorted(set(risk))) if risk else "none",
        "issue_type": "unknown",
        "object_part": "unknown",
        "claim_status": "not_enough_information",
        "claim_status_justification": "Visual evidence could not be reliably interpreted.",
        "supporting_image_ids": "none",
        "valid_image": "false",
        "severity": "unknown",
    }
